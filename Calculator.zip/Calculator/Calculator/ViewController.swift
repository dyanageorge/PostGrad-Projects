//
//  ViewController.swift
//  Calculator
//
//  Created by Dyana George on 9/20/18.
//  Copyright © 2018 Dyana George. All rights reserved.
//

import UIKit

//to have the boader around the button
@IBDesignable extension UIButton {
    
    @IBInspectable var borderWidth: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.borderColor = uiColor.cgColor
        }
        get {
            guard let color = layer.borderColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
}

class ViewController: UIViewController {
//declear var
    var numOnScreen: Double = 0;
    var lastNum: Double = 0;
    var arith = false;
    var storeOpp = 0;
    
    //label outlet
    @IBOutlet weak var DisplayLabel: UILabel!
    
    //for all the number buttons
    @IBAction func NumberButtons(_ sender: UIButton){
        //if there was a calculation done
        if arith == true{
            //then what is on the screen is equal to
            DisplayLabel.text = String(sender.tag - 1)
            //convert what is on the to a text
            numOnScreen = Double(DisplayLabel.text!)!
            arith = false
        }
        else {
            DisplayLabel.text = DisplayLabel.text! + String(sender.tag - 1)
            numOnScreen = Double(DisplayLabel.text!)!
        }

        
    }
    
    @IBAction func mathButtons(_ sender: UIButton){
            //if there is nothing on screen and the clear button was not press
            if DisplayLabel.text != "" && sender.tag != 11 && sender.tag != 19 {
                lastNum = Double(DisplayLabel.text!)!
                //make labels
                if sender.tag == 13{
                    //find percentage
                    DisplayLabel.text = "%"
                }
                else if sender.tag == 14{
                    //divide
                    DisplayLabel.text = "/"
                }
                else if sender.tag == 15{
                    //multiply
                    DisplayLabel.text = "*"
                }
                else if sender.tag == 16{
                    //minus
                    DisplayLabel.text = "-";
                }
                else if sender.tag == 17{
                    //add
                    DisplayLabel.text = "+";
                }
                //to find the total
                storeOpp = sender.tag
                arith = true;
            }
            else if sender.tag == 19{
                if storeOpp == 13{//percentage
                    //if there is an operation done on the
                }
                else if storeOpp == 14{//divide
                    DisplayLabel.text = String(lastNum / numOnScreen)
                }
                else if storeOpp == 15{//multiply
                    DisplayLabel.text = String(lastNum * numOnScreen)
                }
                else if storeOpp == 16{//minus
                    DisplayLabel.text = String(lastNum - numOnScreen)
                }
                else if storeOpp == 17{//add
                    DisplayLabel.text = String(lastNum + numOnScreen)
                }
            }
                //if clear is pressed
            else if sender.tag == 11 {
                DisplayLabel.text = ""
                lastNum = 0;
                numOnScreen = 0;
                storeOpp = 0;
            }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

   

}

